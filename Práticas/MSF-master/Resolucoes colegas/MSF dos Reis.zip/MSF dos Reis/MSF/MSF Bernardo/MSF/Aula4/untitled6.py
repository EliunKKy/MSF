# -*- coding: utf-8 -*-
"""
Created on Mon Mar 28 17:45:16 2022

@author: draki
"""
import matplotlib.pyplot as plt
import numpy as np

xdt1 = -18.62
xdt2 = -19.502
xanalitical = -19.6

print(np.abs(xdt1))