import matplotlib.pyplot as plt
import numpy as np
import sympy as sym
a = np.array([1,2,0])
b = np.array([3,-2,2])
s = a+b
d = b-a
pv = a*b
pe = b[0]*a[0]+b[1]*a[1]+b[2]*a[2]